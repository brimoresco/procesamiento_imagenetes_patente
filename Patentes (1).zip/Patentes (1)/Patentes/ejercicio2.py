
##imagen 1

import cv2
from matplotlib import pyplot as plt
import numpy as np


def imshow(img, new_fig=True, title=None, color_img=False, blocking=False, colorbar=True, ticks=False):
    if new_fig:
        plt.figure()
    if color_img:
        plt.imshow(img)
    else:
        plt.imshow(img, cmap='gray')
        plt.title(title)
    if not ticks:
        plt.xticks([]), plt.yticks([])
    if colorbar:
        plt.colorbar()
    if new_fig:
        plt.show(block=blocking)
   
# --- Cargo imagen --------------------------------------------------------------------------------
img = cv2.imread('Patentes/img02.png', cv2.IMREAD_COLOR)
img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
plt.figure(), plt.imshow(img), plt.show(block=False)
H, W = img.shape[:2]

# --- Paso a escala de grises ---------------------------------------------------------------------
img_fil_gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
plt.figure(), plt.imshow(img_fil_gray, cmap='gray'), plt.show(block=False)

# --- Binarizo ------------------------------------------------------------------------------------
th, binary_img = cv2.threshold(img_fil_gray, 125, 1, cv2.THRESH_OTSU)
plt.figure(), plt.imshow(binary_img, cmap='gray'), plt.show(block=False)

# --- Operaciones morfológicas para mejorar la segmentación obtenida ------------------------------
se = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2, 2))
# Aplicar operaciones morfológicas para mejorar la segmentación
kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (2, 2))

#------------------
binary_img = cv2.morphologyEx(binary_img, cv2.MORPH_ERODE, se)  # Clausura para rellenar huecos.
plt.figure(), plt.imshow(binary_img, cmap='gray'), plt.show(block=False)

# --- Obtengo componentes conectados --------------------------------------------------------------
num_labels, labels, stats, centroids = cv2.connectedComponentsWithStats(binary_img)
plt.figure(), plt.imshow(labels, cmap='gray'), plt.show(block=False)        # Visualizo los objetos con sus labels en ESCALA DE GRISES



#agregar otra flag mas que filtre por relacion de aspecto ancho sobre alto letra
AREA_min = 20
area_max = 250          # Umbral de area
aux = np.zeros_like(labels)
ancho_min = 10
ancho_max = 50
labeled_image = cv2.merge([aux, aux, aux])

# --- Clasificación ---------------------------------------------------------------------
# Clasifico en base al factor de forma
for i in range(1, num_labels):
    flag = False
    # --- Remuevo celulas con area chica -----------
    if (stats[i][cv2.CC_STAT_AREA] > AREA_min and stats[i][cv2.CC_STAT_AREA] < area_max) :
    #and (stats[i][cv2.CC_STAT_WIDTH] > ancho_min and stats[i][cv2.CC_STAT_WIDTH] < ancho_max):
        flag = True

    # --- Selecciono el objeto actual -------------------
    obj = (labels == i).astype(np.uint8)
    
    # --- Muestro por pantalla el resultado -----------------------------------
    
    # --- Clasifico -----------------------------------------------------------
    if flag and stats[i][cv2.CC_STAT_WIDTH] < stats[i][cv2.CC_STAT_HEIGHT]:
        labeled_image[obj == 1, 1] = 255    
    print(f"Obj--> area: {stats[i, cv2.CC_STAT_AREA]} " )    
    
plt.figure(); plt.imshow(labeled_image); plt.show(block=False)
                                                            
labels_color = np.uint8(255/(num_labels-1)*labels)                  
# np.unique(labels_color)      



#1